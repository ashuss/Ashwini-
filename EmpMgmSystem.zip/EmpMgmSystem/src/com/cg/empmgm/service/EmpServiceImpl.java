package com.cg.empmgm.service;

import java.util.ArrayList;
import java.util.regex.Pattern;

import com.cg.empmgm.bean.Employee;
import com.cg.empmgm.dao.EmpDao;
import com.cg.empmgm.dao.EmpDaoImpl;
import com.cg.empmgm.exception.EmployeeException;

public class EmpServiceImpl 
implements EmpService
{
	EmpDao empDao = null;
	public  EmpServiceImpl()
	{
		empDao = new EmpDaoImpl();
	}
	
	
	@Override
	public int addEmp(Employee emp) throws
	EmployeeException
	{
		return empDao.addEmp(emp);
	}


	@Override
	public ArrayList<Employee> getAllEmp() throws EmployeeException 
	{
		
		return empDao.getAllEmp();
	}


	@Override
	public int generateEmpId(Employee emp) throws EmployeeException 
	{
		
		return empDao.generateEmpId();
	}

	/****************** Validate id ********************************/
	
	@Override
	public boolean validateDigit(int empId) throws EmployeeException 
	{
		String numPattern = "[0-9]{4}";
		if(Pattern.matches(numPattern, new Integer(empId).toString()))		//convert int into string
		{
			return true;
		}
		else
		{
			throw new EmployeeException("Only Min 4 digits allowed in empid");
		}
	}

	/*************************** Validate name ***********************************/

	@Override
	public boolean validateName(String empName) throws EmployeeException 
	{
		String namePattern="[A-Z][a-z]+";
		if(Pattern.matches(namePattern, empName))
		{
			return true;
		}
		else
		{
			throw new EmployeeException("Only Chars Allowed and starts with capital e.g Ashwini");
		}
		
	}


	@Override
	public int deleteEmp(int empId) throws EmployeeException {
		return empDao.deleteEmp(empId);
	}


	@Override
	public int updateEmp(int eid) throws EmployeeException {
		return empDao.updateEmp(eid);
	}
	
	
}

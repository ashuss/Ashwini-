package com.cg.admission.service;

import java.util.regex.Pattern;

import com.cg.admission.bean.UniversityAdmission;
import com.cg.admission.dao.AdmDao;
import com.cg.admission.dao.AdmDaoImpl;
import com.cg.admission.exception.AdmissionException;



public class AdmServiceImpl 
implements AdmService
{
	AdmDao admDao = null;
	public  AdmServiceImpl()
	{
		admDao = new AdmDaoImpl();
	}

	@Override
	public int addAppliantDetails(UniversityAdmission applicant)
			throws AdmissionException 
	{
		return admDao.addAppliantDetails(applicant);
	}

	@Override
	public long generateApplicantId(long aaplicantId) throws AdmissionException
	{
		return admDao.generateApplicantId(aaplicantId);
	}

	@Override
	public UniversityAdmission getAppliantDetails(long applicantId) throws AdmissionException
	{
		return admDao.getAppliantDetails(applicantId);
	}

	@Override
	public boolean isValidapplicant(long aid) throws AdmissionException 
	{
		String numPattern = "[0-9]{4}";
		if(Pattern.matches(numPattern, new Long(aid).toString()))
		{
			return true;
		}
		else
		{
			throw new AdmissionException("Only Min 4 digits allowed in empid");
		}
	}

	@Override
	public boolean validateContactNo(long contactNo) throws AdmissionException 
	{
		String numPattern = "[7-9][0-9]{9}";
		if(Pattern.matches(numPattern, new Long(contactNo).toString()))
		{
			return true;
		}
		else
		{
			throw new AdmissionException("Invalid Phone No");
		}
	}

	@Override
	public boolean validateFirstname(String fName) throws AdmissionException 
	{
		String namePattern="[A-Z][a-z]{1,10}";
        if(Pattern.matches(namePattern, fName))
        {
            return true;
        }
        else
        {
            throw new AdmissionException("Only characters allowed and starts with Capital e.g. Asmita");
        }   
	}

	@Override
	public boolean validateLastname(String lName) throws AdmissionException 
	{
		String namePattern="[A-Z][a-z]{1,10}";
        if(Pattern.matches(namePattern, lName))
        {
            return true;
        }
        else
        {
            throw new AdmissionException("Only characters allowed and starts with Capital e.g. Patil");
        } 
	}

	@Override
	public boolean validateEmail(String pLocation) throws AdmissionException 
	{
		String email="^[_A-Za-z0-9-\\+]+(\\.[_A-Za-z0-9-]+)*@"
                + "[A-Za-z0-9-]+(\\.[A-Za-z0-9]+)*(\\.[A-Za-z]{2,})$";
                
        if(Pattern.matches(email, pLocation))
         {
               return true;
         }
         else
         {
               throw new AdmissionException("Enter valid EmailId eg.asmita.patil@gmail.com");
         }
	}

	@Override
	public boolean validateAggregate(float aggregate) throws AdmissionException
	{
		String agg="[0-9]*\\.?[0-9]*";
        
        if(Pattern.matches(agg, new Float(aggregate).toString()))
        {
            return true;
        }
        else
        {
            throw new AdmissionException("Enter valid EmailId eg.asmita.patil@gmail.com");
        }
	}

	@Override
	public boolean validateStream(String stream) throws AdmissionException
	{
		if(stream.equals("Computer Science") || stream.equals("Information Technology"))
		{
			return true;
		}
		else
		{
			throw new AdmissionException("Stream Must be either Computer Science or Information Technology");
		}
	}

	
	
	
	

	

	
	
	

}

package com.cg.admission.ui;


import java.util.Scanner;

import com.cg.admission.bean.UniversityAdmission;
import com.cg.admission.exception.AdmissionException;
import com.cg.admission.service.AdmService;
import com.cg.admission.service.AdmServiceImpl;





public class ApplicantAdmin 
{
	static Scanner sc = null;
	static AdmService admSer = null;
	
	public static void main(String[] args) 
	{
		admSer = new AdmServiceImpl();
		sc = new Scanner(System.in);
		int choice = 0 ; 
		
		while(true)
		{
			System.out.println("***************Admission System****************");
			System.out.println("Select an Operation: ");
			System.out.println("1. Enter Details\n2. View Details based on Application Id\n 0. Exit");
			System.out.println("****************************");
			System.out.println("Please enter a Choice : ");
			choice = sc.nextInt();
			System.out.println("****************************");
			switch(choice)
			{
			case 1: 
				insertApplicant();
				break;
				
			case 2:
				fetchApplicantDetails();
				break;
				
			default : System.exit(0);	
			}
		}

	}

	/*********************Main end Here*****************************/
	
	private static void insertApplicant() 
	{
		System.out.println("Enter first name : ");
		String fname = sc.next();
		try
		{
			if(admSer.validateFirstname(fname))
			{
				System.out.println("Enter last name : ");
				String lname = sc.next();
				if(admSer.validateLastname(lname))
				{
					System.out.println("Enter Contact Number : ");
					long phoneNo = sc.nextLong();
					if(admSer.validateContactNo(phoneNo))
					{
						System.out.println("Enter Email id : ");
						String email = sc.next();
						if(admSer.validateEmail(email))
						{
							System.out.println("Enter Aggregate in qualifying exam : ");
							float agg = sc.nextFloat();
							if(admSer.validateAggregate(agg))
							{
								System.out.println("Enter Stream : ");
								sc.nextLine();
								String st = sc.nextLine();
								if(admSer.validateStream(st))
								{
									UniversityAdmission ua = new UniversityAdmission();
									
									ua.setfName(fname);
									ua.setlName(lname);
									ua.setContactNo(phoneNo);
									ua.setEmail(email);
									ua.setAggregate(agg);
									ua.setStream(st);
									
									int dataAdded = admSer.addAppliantDetails(ua);
									if(dataAdded == 1)
									{
										System.out.println("Emp Data Added: ");
									}
									else
									{
										System.out.println("May be Some Exception while addition");
									}
								}
							}
						}
					}
				}
			}
		}
		catch (AdmissionException e) 
		{
			
			System.out.println(e.getMessage());
		}
} 
		
		
		
	
	
	/**************************************************************/
	
	private static void fetchApplicantDetails() 
	{
		System.out.println("Enter the Applicant Id : ");
		long id = sc.nextLong();
		try
		{
			UniversityAdmission applicantData = admSer.getAppliantDetails(id);
			if(applicantData != null)
			{
				System.out.println("Applicant Details: ");
				System.out.println(applicantData);
			}
			else
			{
				System.out.println("Sorry No Details Found ! ");
			}
			
		}
		catch (AdmissionException e) 
		{
			
			System.out.println(e.getMessage());
		}	
		
			
		
	}

	

}

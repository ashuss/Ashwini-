package com.cg.admission.junit;

import org.junit.Assert;
import org.junit.BeforeClass;
import org.junit.Test;

import com.cg.admission.bean.UniversityAdmission;
import com.cg.admission.dao.AdmDao;
import com.cg.admission.dao.AdmDaoImpl;
import com.cg.admission.exception.AdmissionException;

public class AdmDaoImplTest 
{

	static AdmDao admDao = null;
	static UniversityAdmission ua = null;
	
	@BeforeClass
	public  static void EmpDaoImplTests() throws AdmissionException
	{
		admDao = new AdmDaoImpl();
		//ua = new UniversityAdmission(admDao.generateApplicantId(),"XYZ","PQR","xyz@gmail.com",784512638,"Computer",(float) 89.6);
		
	}
	
	@Test
	public void testAddEmp1() throws AdmissionException
	{
		Assert.assertEquals(1, admDao.addAppliantDetails(ua));
	}
	
	@Test(expected = Exception.class)
	public void testAddEmp2() throws AdmissionException
	{
		Assert.assertEquals(1, admDao.addAppliantDetails(ua));
	}
	
	
}

package com.cg.contactbook.junit;

import junit.framework.Assert;

import org.junit.BeforeClass;
import org.junit.Test;

import com.cg.contactbook.bean.EnquiryBean;
import com.cg.contactbook.dao.ContactBookDao;
import com.cg.contactbook.dao.ContactBookDaoImpl;
import com.cg.contactbook.exception.ContactBookException;

public class CbDaoImplTest 
{
	static ContactBookDao cbDao=null;
	static EnquiryBean ee=null;
	
	@BeforeClass
	public static void beforeClass() throws ContactBookException
	{
		cbDao=new ContactBookDaoImpl();
		ee=new EnquiryBean(cbDao.generateEnqryId(),"Aishu","Sawant",9920680901L,"Java","Pune");
	}
	
	@Test
	public void testaddEnquiry1()throws ContactBookException
	{
		Assert.assertEquals(1,cbDao.addEnquiry(ee));
	}
	
	@Test(expected=Exception.class)
	public void testaddEnquiry2()throws ContactBookException
	{
		Assert.assertEquals(1,cbDao.addEnquiry(ee));
	}
	
	/*@Test
	public void testaddEnquiry3()throws ContactBookException
	{
		Assert.assertNotNull(cbDao.getEnquiryDetails(int EnquiryID));
	}*/
}

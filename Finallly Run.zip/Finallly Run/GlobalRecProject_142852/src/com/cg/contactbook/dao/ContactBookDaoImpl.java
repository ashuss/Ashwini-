package com.cg.contactbook.dao;
import java.sql.*;


import org.apache.log4j.Level;
import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;

import com.cg.contactbook.bean.EnquiryBean;
import com.cg.contactbook.exception.ContactBookException;
import com.cg.contactbook.util.DBUtil;



public class ContactBookDaoImpl implements ContactBookDao
{
	
	Connection con=null;
	Statement st=null;
	PreparedStatement pst=null;
	ResultSet rs=null;
	int dataAdded;
	
	Logger globalRec=null;
	
	public ContactBookDaoImpl()
	{
		PropertyConfigurator.configure("resources/log4j.properties");
		globalRec=Logger.getLogger("ContactBookDaoImpl.class");
	}
	
	@Override
	public int generateEnqryId() throws ContactBookException 
	{

		String qry="SELECT enquiries.NEXTVAL FROM DUAL";
		int generatedVal;
		try 
		{
			con=DBUtil.getCon();
			st=con.createStatement();
			rs=st.executeQuery(qry);
			
			rs.next();
			 generatedVal=rs.getInt(1);
		} 
		catch (Exception e) 
		{
			throw new ContactBookException(e.getMessage());
		}
		finally
		{
			try 
			{
				rs.close();
				 st.close();
				con.close();
			} 
		   catch (SQLException e) 
			{
				throw new ContactBookException(e.getMessage()); 
			}
		}
		return generatedVal;
	}

	
	@Override
	public int addEnquiry(EnquiryBean enqry) throws ContactBookException
	{
		int id;
		String insertQry="Insert INTO Enquiry VALUES (?,?,?,?,?,?)";
		try
		{
			con=DBUtil.getCon();
			pst=con.prepareStatement(insertQry);
			
			id=generateEnqryId();
			pst.setInt(1,id);
			pst.setString(2,enqry.getFname());
			pst.setString(3,enqry.getLname());
			pst.setLong(4,enqry.getContactNo());
			pst.setString(5,enqry.getpLocation());          //(5,(String)enqry.getGender); if char is asked
			pst.setString(6,enqry.getpDomain());
			
			
			
			
			dataAdded=pst.executeUpdate();	
			
			globalRec.log(Level.INFO,"Data Inserted: "+enqry);

		} 
		 catch (Exception e)
		{
			 globalRec.error("This is Exception: " +e.getMessage());
			 throw new ContactBookException(e.getMessage());
		}
		finally
		{
			try 
			{
				pst.close();
				con.close();
			} 
			catch (Exception e) 
			{
				
				 throw new ContactBookException(e.getMessage());
			}
			
		}
		return id;
	}

	@Override
	public EnquiryBean getEnquiryDetails(int EnquiryID)throws ContactBookException 
	{
		String selectQry="SELECT * FROM enquiry WHERE enqryId=?";
		EnquiryBean ee=null;
		try 
		{
			con=DBUtil.getCon();
			pst=con.prepareStatement(selectQry);
			pst.setInt(1,EnquiryID);
			
		    
	        rs = pst.executeQuery();
          
	        
	       if(rs.next())
	           {
	            	ee=new EnquiryBean(rs.getInt("enqryId"),  //spellings of table. not case-sensitive
	            			rs.getString("firstname"),			//order of bean class constructor
	            			rs.getString("lastname"),
	            			rs.getLong("contactNo"),
	            			rs.getString("city"),
	            			rs.getString("domain"));
	            	
	           }
	           
		}
		catch (Exception e) 
		{
			throw new ContactBookException(e.getMessage());
		}
		finally
		{
			try 
			{
				rs.close();
				pst.close();
				con.close();
			} 
		   catch (SQLException e) 
			{
				throw new ContactBookException(e.getMessage()); 
			}
		}
		return ee;
	}
}

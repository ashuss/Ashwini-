package com.cg.contactbook.ui;

import java.util.Scanner;

import com.cg.contactbook.bean.EnquiryBean;
import com.cg.contactbook.exception.ContactBookException;
import com.cg.contactbook.service.ContactBookService;
import com.cg.contactbook.service.ContactBookServiceImpl;


public class Client
{

	static Scanner sc=null;
	static ContactBookService cbSer=null;

	public static void main(String[] args) 
	{
		cbSer=new ContactBookServiceImpl();
		sc=new Scanner(System.in);

		int choice=0;
		while(true)
		{
			System.out.println("*****************Global Recruitments****************");
			System.out.println("Choose an operation");
			System.out.println("1:Enter Enquiry Details \n2:View Enquiry Details \n0:Exit");
			System.out.println("**************************************************************");
			System.out.println("Please enter a choice: ");
			System.out.println("**************************************************************");
			choice=sc.nextInt();
			switch(choice)
			{
			case 1: addEnquiry();
				break;
			case 2: getEnquiryDetails();
				break;
			default : System.exit(0);
				
			}
	
		}
	}
	


	
	/***************main ends here****************/
	
	
	public static void addEnquiry()
	{
		System.out.println("Enter First Name : ");
		String fnm=sc.next();
		try
		{
			if(cbSer.validateFName(fnm))
			{
				System.out.println("Enter Last Name : ");
				String lnm=sc.next();
				if(cbSer.validateFName(lnm))
				{
					System.out.println("Enter Contact Number : ");
					long num=sc.nextLong();
					if(cbSer.validateNumber(num))
					{
						System.out.println("Enter Preferred Domain : ");
						String domain=sc.next();
						if(cbSer.validateDomain(domain))
						{
							System.out.println("Enter Preferred Location : ");
							String location=sc.next();
							if(cbSer.validateLocation(location))
							{
								EnquiryBean ee=new EnquiryBean();
								ee.setFname(fnm);
								ee.setLname(lnm);
								ee.setContactNo(num);
								ee.setpDomain(domain);
								ee.setpLocation(location);
								
								int dataAdded=cbSer.addEnquiry(ee);
								if(dataAdded!=0)
								{
									System.out.println("\n********************************************\n");
									System.out.println("Thank you" +fnm+ " " +lnm+
											"your Unique Id is" +dataAdded+ 
											" we will contact you shortly.");
									System.out.println("\n********************************************");
								}
								else
								{
									System.out.println("May give some exception while addition. ");
								}
							}
						}
					}
				}
			}
		}
	
		catch (ContactBookException e) 
		{
			System.out.println(e.getMessage());
		}
	
	}
	
	public static void getEnquiryDetails()
	{
		System.out.println("Enter the Enquiry No. : ");
		int no=sc.nextInt();
		
		try
		{
			EnquiryBean ee= cbSer.getEnquiryDetails(no);
			System.out.println("Id \t First Name \t Last Name \t Contact No. \t Preferred Domain \t Preferred Location");
					System.out.println(ee);
		}
		catch(ContactBookException e)
		
		{
			System.out.println("Some exception while fetching data");
		}
	
	}
}	
		
		
	

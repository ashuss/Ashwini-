package com.cg.contactbook.service;

import com.cg.contactbook.bean.EnquiryBean;
import com.cg.contactbook.exception.ContactBookException;


public interface ContactBookService
{
	public int addEnquiry(EnquiryBean enqry)throws ContactBookException;
	
	public EnquiryBean getEnquiryDetails(int EnquiryID)throws ContactBookException;	
	
	public boolean isValidEnquiry(EnquiryBean enqry)throws ContactBookException;
	
	public boolean validateNumber(long contactNo) throws ContactBookException;
	
	public boolean validateFName(String fName) throws ContactBookException;
	
	public boolean validateLName(String lName) throws ContactBookException;
	
	public boolean validateLocation(String location) throws ContactBookException;
	
	public boolean validateDomain(String domain) throws ContactBookException;
	
	
	
	
}

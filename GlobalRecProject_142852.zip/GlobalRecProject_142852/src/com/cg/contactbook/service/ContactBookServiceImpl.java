package com.cg.contactbook.service;

import java.util.regex.Pattern;

import com.cg.contactbook.bean.EnquiryBean;
import com.cg.contactbook.dao.ContactBookDao;
import com.cg.contactbook.dao.ContactBookDaoImpl;
import com.cg.contactbook.exception.ContactBookException;

public class ContactBookServiceImpl implements ContactBookService
{
	ContactBookDao cbDao=null;
	
	public ContactBookServiceImpl()
	{
		cbDao=new ContactBookDaoImpl();  
	}
	
	@Override
	public int addEnquiry(EnquiryBean enqry) throws ContactBookException 
	{
		
		return cbDao.addEnquiry(enqry);
	}

	@Override
	public boolean isValidEnquiry(EnquiryBean enqry)throws ContactBookException
	{
		String numPattern="{4}";
		if(Pattern.matches(numPattern, enqry.toString()))
		{
			return true;
		}
		else
		{
			throw new ContactBookException ("Sorry, no details found!");
		}
	
	}

	@Override
	public EnquiryBean getEnquiryDetails(int EnquiryID)
			throws ContactBookException 
	{
		
		return cbDao.getEnquiryDetails(EnquiryID);
	}

	@Override
	public boolean validateNumber(long contactNo)throws ContactBookException 
	{
		String numPattern="[1-9]{1}[0-9]{9}";
		if(Pattern.matches(numPattern, new Long(contactNo).toString()))
		{
			return true;
		}
		else
		{
			throw new ContactBookException ("Minimum 10 digits allowed in contact number");
		}
	}


	@Override
	public boolean validateFName(String fName) throws ContactBookException
	{
		String namePattern="[A-Z][a-z]+";
		if(Pattern.matches(namePattern,fName))
		{
			return true;
		}
		else 
		{
			throw new ContactBookException("Only alphabets can be accepted and first letter should be capital.");
			
		}
	}

	@Override
	public boolean validateLName(String lName) throws ContactBookException 
	{
		String namePattern="[A-Z][a-z]+";
		if(Pattern.matches(namePattern,lName))
		{
			return true;
		}
		else
		{
			throw new ContactBookException("Only alphabets can be accepted and first letter should be capital..");
			
		}
	}

	@Override
	public boolean validateLocation(String location)throws ContactBookException 
	{
		String namePattern="[A-Z][a-z]+";
		if(Pattern.matches(namePattern,location))
		{
			return true;
		}
		else
		{
			throw new ContactBookException("Only alphabets can be accepted and first letter should be capital..");
			
		}
	}

	@Override
	public boolean validateDomain(String domain) throws ContactBookException 
	{
		String namePattern="[A-Z][a-z]+";
		if(Pattern.matches(namePattern,domain))
		{
			return true;
			
		}
		else
		{
			throw new ContactBookException("Only alphabets can be accepted and first letter should be capital..");
		}
	}

}

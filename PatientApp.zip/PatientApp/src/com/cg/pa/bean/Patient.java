package com.cg.pa.bean;

import java.time.LocalDate;

public class Patient 
{
	private int patId;
	private String name;
	private int age;
	private long phoneNo;
	private String description;
	private LocalDate consult_date;
	
	
	public Patient() 
	{
		super();
	}


	public Patient(int patId, String name, int age, long phoneNo,
			String description, LocalDate consult_date) {
		super();
		this.patId = patId;
		this.name = name;
		this.age = age;
		this.phoneNo = phoneNo;
		this.description = description;
		this.consult_date = consult_date;
	}


	public int getPatId() {
		return patId;
	}


	public void setPatId(int patId) {
		this.patId = patId;
	}


	public String getName() {
		return name;
	}


	public void setName(String name) {
		this.name = name;
	}


	public int getAge() {
		return age;
	}


	public void setAge(int age) {
		this.age = age;
	}


	public long getPhoneNo() {
		return phoneNo;
	}


	public void setPhoneNo(long phoneNo) {
		this.phoneNo = phoneNo;
	}


	public String getDescription() {
		return description;
	}


	public void setDescription(String description) {
		this.description = description;
	}


	public LocalDate getConsult_date() {
		return consult_date;
	}


	public void setConsult_date(LocalDate consult_date) {
		this.consult_date = consult_date;
	}


	@Override
	public String toString() {
		return "Patient [patId=" + patId + ", name=" + name + ", age=" + age
				+ ", phoneNo=" + phoneNo + ", description=" + description
				+ ", consult_date=" + consult_date + "]";
	}
	
	
	
	
	
}

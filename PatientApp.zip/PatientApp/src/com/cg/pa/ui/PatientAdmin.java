package com.cg.pa.ui;

import java.util.Scanner;



import com.cg.pa.bean.Patient;
import com.cg.pa.exception.PatientException;
import com.cg.pa.service.PatientService;
import com.cg.pa.service.PatientServiceImpl;



public class PatientAdmin 
{
	static Scanner sc = null;
	static PatientService pSer = null;

	public static void main(String[] args) 
	{
		pSer = new PatientServiceImpl();
		sc = new Scanner(System.in);
		int choice = 0 ; 
		
		while(true)
		{
			System.out.println("***************Admission System****************");
			System.out.println("Select an Operation: ");
			System.out.println("1. Enter Details\n2. View Details based on Application Id\n 0. Exit");
			System.out.println("****************************");
			System.out.println("Please enter a Choice : ");
			choice = sc.nextInt();
			System.out.println("****************************");
			switch(choice)
			{
			case 1: 
				insertPatient();
				break;
				
			case 2:
				fetchPatientDetails();
				break;
				
			default : System.exit(0);	
			}
		}

	}

	private static void insertPatient()
	{
		System.out.println("Enter Patient Name : ");
		String name = sc.next();
		try 
		{
			if(pSer.validateName(name))
			{
				System.out.println("Enter Age : ");
				int age = sc.nextInt();
				if(pSer.validateAge(age))
				{
					System.out.println("Enter Contact Number : ");
					long ph = sc.nextLong();
					if(pSer.validateContactNo(ph))
					{
						System.out.println("Enter Description : ");
						sc.nextLine();
						String des = sc.nextLine();
						
						Patient pat = new Patient();
						
						pat.setName(name);
						pat.setAge(age);
						pat.setPhoneNo(ph);
						pat.setDescription(des);
						
						int dataAdded = pSer.addPatientDetails(pat);
						
						if(dataAdded == 1)
						{
							System.out.println("Patient Data Added: ");
						}
						else
						{
							System.out.println("May be Some Exception while addition");
						}
					}
				}
			}
		} 
		catch (PatientException e) 
		{
			System.out.println(e.getMessage());
		}
		
	}

	private static void fetchPatientDetails()
	{
		System.out.println("Enter the Patient Id : ");
		int id = sc.nextInt();
		try {
			if(pSer.isValidPatient(id))
			{
				Patient p = pSer.getAppliantDetails(id);
				System.out.println(p);
			}
			else
			{
				System.out.println("Sorry No Details Found ! ");
			}
		} 
		catch (PatientException e1) 
		{
			System.out.println(e1.getMessage());
		}
		
	}

}

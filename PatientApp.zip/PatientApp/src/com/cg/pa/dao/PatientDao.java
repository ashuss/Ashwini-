package com.cg.pa.dao;

import java.util.ArrayList;

import com.cg.pa.bean.Patient;
import com.cg.pa.exception.PatientException;

public interface PatientDao 
{
	public int addPatientDetails(Patient patient)
	throws PatientException;
	
	public int generatePatientId() 
	throws PatientException;
	
	
	public Patient getAppliantDetails(int patientId)
	throws PatientException;
	
	public ArrayList<Integer> validatePatientId()
	throws PatientException;
}
